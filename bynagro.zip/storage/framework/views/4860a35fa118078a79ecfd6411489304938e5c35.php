<?php $__env->startSection("wrapper"); ?>
    <div class="">
        <?php if ($__env->exists("layouts.navbar")) echo $__env->make("layouts.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="">
            <?php echo $__env->yieldContent("content"); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bynagro\resources\views/layouts/app.blade.php ENDPATH**/ ?>