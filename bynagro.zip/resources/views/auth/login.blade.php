@extends('layouts.app')

@section('content')
    <div class="p-10 bg-red-500">
        <h1 class="text-4xl">Login Page</h1>
    </div>
@endsection
