
@extends('layouts.app')

@section('content')

    <div class="mt-24 py-24 px-5 font-poppins">
        <h1 class="text-4xl font-black">This Page is under construction</h1>
        <h3>Will be available soon</h3>
    </div>

@endsection
