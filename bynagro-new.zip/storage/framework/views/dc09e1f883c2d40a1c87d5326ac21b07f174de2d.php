<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(["class" => "h-64"]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(["class" => "h-64"]); ?>
<?php foreach (array_filter((["class" => "h-64"]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<header class="relative <?php echo e($class); ?>">
    <img src="/images/slides/cows.jfif" alt="" class="block w-full h-full object-cover">
    <div class="bg-black/70 absolute top-0 left-0 w-full h-full flex flex-col">

        <div class="mt-24 flex items-center justify-center text-white flex-grow flex-col gap-5">
            <?php echo e($slot); ?>

        </div>
    </div>
</header>
<?php /**PATH C:\laragon\www\bynagro\resources\views/components/header.blade.php ENDPATH**/ ?>