<?php $__env->startSection("content"); ?>


    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-3xl">Our Agricultural Products</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="services max-w-[1200px] mx-auto space-y-24 mt-10">
        <div v-for="service in services" class="service p-5 grid md:grid-cols-2 gap-10">
            <div class="">
                <div class="h-96 bg-green-300"></div>
            </div>
            <div class="space-y-5">
                <h1 v-text="service.title" class="text-2xl md:text-4xl"></h1>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    A perferendis amet dolorum exercitationem, aperiam numquam harum.
                    Mollitia vitae debitis non temporibus quas, accusantium quos,
                    enim magnam ipsa corporis labore accusamus?
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    A perferendis amet dolorum exercitationem, aperiam numquam harum.
                    Mollitia vitae debitis non temporibus quas, accusantium quos,
                    enim magnam ipsa corporis labore accusamus?
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    A perferendis amet dolorum exercitationem, aperiam numquam harum.
                    Mollitia vitae debitis non temporibus quas, accusantium quos,
                    enim magnam ipsa corporis labore accusamus?
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bynagro\resources\views/products.blade.php ENDPATH**/ ?>