<?php $__env->startSection('content'); ?>

    <div class="mt-24 py-24 px-5 font-poppins">
        <h1 class="text-4xl font-black">This Page is under construction</h1>
        <h3>Will be available soon</h3>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bynagro\resources\views/components/comming-soon.blade.php ENDPATH**/ ?>