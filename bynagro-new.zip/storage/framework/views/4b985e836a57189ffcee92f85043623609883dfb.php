<?php $__env->startSection("content"); ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <h1 class="text-3xl">About Us</h1>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="max-w-[1200px] mx-auto py-10 space-y-6 md:space-y-24">
        <div class="grid md:grid-cols-2">
            <div class="bg-gradient-to-tr from-primary to-black hidden md:block">
                <img src="/images/slides/cows.jfif" alt="" class="opacity-80">
            </div>
            <div class="p-5 space-y-5">
                <h2 class="text-3xl md:text-4xl">BYN AGRO ALLIED LTD</h2>
                <p class="text-lg md:text-xl">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                </p>
                <a href="<?php echo e(route("contact")); ?>" class="inline-block px-5 py-3 rounded-full bg-primary font-bold">
                    Get in Touch <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>

        <div class="grid md:grid-cols-2">
            <div class="p-5 space-y-5">
                <h2 class="text-3xl md:text-4xl">Our Vission</h2>
                <p class="text-lg md:text-xl">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                </p>
                <a href="<?php echo e(route("contact")); ?>" class="inline-block px-5 py-3 rounded-full bg-primary font-bold">
                    Get in Touch <i class="bi bi-arrow-right"></i>
                </a>
            </div>

           <div class="bg-gradient-to-tr from-primary to-black hidden md:block">
                <img src="/images/slides/cows.jfif" alt="" class="opacity-80">
            </div>
        </div>

        <div class="grid md:grid-cols-2">
            <div class="bg-gradient-to-tr from-primary to-black hidden md:block">
                <img src="/images/slides/cows.jfif" alt="" class="opacity-80 object-cover">
            </div>
            <div class="p-5 space-y-5">
                <h2 class="text-3xl md:text-4xl">Our Mission</h2>
                <p class="text-lg md:text-xl">
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Maiores, reprehenderit?
                </p>
                <a href="<?php echo e(route("contact")); ?>" class="inline-block px-5 py-3 rounded-full bg-primary font-bold">
                    Get in Touch <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bynagro\resources\views/about.blade.php ENDPATH**/ ?>